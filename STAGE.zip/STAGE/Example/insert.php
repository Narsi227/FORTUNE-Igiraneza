<?php
include'connection.php';
if($_SERVER["REQUEST_METHOD"]=="POST"){
    $Name=$_POST['Name'];
    $email=$_POST['email'];
    $sql="INSERT INTO ohh(Name,email)VALUE($Name,$imail)";
    $conn->query($sql);
    header("location:read.php")
}
?>
<form method="post">
<fieldset><legend>LIST OF PEOPLE</legeng>