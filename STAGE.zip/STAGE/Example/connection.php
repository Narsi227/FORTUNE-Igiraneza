<?php
$host='localhost';
$user='root';
$pas='';
$db='example';
$conn=new mysqli($host,$user,$pas,$db);
if($conn->connect_error){
    die("connection failed:".$conn->connect_error);
}
?>