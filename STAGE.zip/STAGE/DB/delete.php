<?php
include 'db_connection.php';
if(isset($_GET['id'])){
    $id=intval($_GET['id']);
    $sql="DELETE FROM user WHERE id=$id";
    $con->query($sql);
    header("location:read.php");
}
$con->close();
?>