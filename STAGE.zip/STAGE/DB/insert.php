<?php
include 'db_connection.php';
if($_SERVER["REQUEST_METHOD"]=="POST"){
    $fname=$_POST['fname'];
    $lname=$_POST['lname'];
    $email=$_POST['email'];
    $sql="INSERT INTO user(fname,lname,email) VALUES('$fname','$lname','$email')";
    $con->query($sql);
    header("location:read.php");
}
?>
<html>
    <head>
        <style>
            form{
                background: blue;
                text-align: center;
            }
            h1{
                color: white;
            }
            legend{
                color: cyan;
                font-size: 30px; 
            }
        </style>
    </head>
<form method="POST">
    <fieldset><legend>User Registration</legend><h1>
    First Name:<input type="text" name="fname" require><br>
    Last Name:<input type="text" name="lname" require><br>
    Email Name:<input type="text" name="email" require><br>
        </h1>
    <center><input type="submit"></center>
</fieldset>
</form>
</html>