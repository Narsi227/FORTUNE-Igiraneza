<?php
session_start();
include 'db_connection.php';
if($_SERVER['REQUEST_METHOD']=='POST'){
    $username=$_POST['username'];
    $password=$_POST['password'];
    $sql="SELECT*FROM login WHERE username='$username' AND password='$password'";
    $result=$con->query($sql);
    if($result->num_rows>0){
        $row=$result->fetch_assoc();
        if($password==$row['password']){
            $_SESSION['username']=$username;
            header('location:insert.php');
            exit();
        }else{
            echo"<script>alert('Invalid Password');</script>";
        }
    }
}
?>
<form method="POST" action="login.php">
    <input type="text" name="username"><br>
    <input type="password" name="password"><br>
    <button type="submit">Login</button>
</form>