<?php
include 'db_connection.php';
if($_SERVER['REQUEST_METHOD']=='POST'){
    $id=$_POST['id'];
     $fname=$_POST['fname'];
     $lname=$_POST['lname'];
     $email=$_POST['email'];
     $sql="UPDATE user SET fname='$fname',lname='$lname',email='$email' WHERE id=$id";
     if($con->query($sql)===TRUE){
        header("location:read.php");
     }
     else{
        echo"error".$con->error;
     }}
     $id=$_GET['id'];
     $sql="SELECT*FROM user WHERE id=$id";
     $result=$con->query($sql);
     $row=$result->fetch_assoc();
?>
<form method="POST" action="update.php">
    <h1>List of users to update</h1>
    <input type="hidden" name="id" value="<?php echo $row['id']; ?>"><br>
    <input type="text" name="fname" value="<?php echo $row['fname']; ?>"><br>
    <input type="text" name="lname" value="<?php echo $row['lname']; ?>"><br>
    <input type="text" name="email" value="<?php echo $row['email']; ?>"><br>
    <button type="submit">Edit</button>
</form>