<?php
$host='localhost';//servername
$user='root';
$pass="";
$db='db_management';
//database connections      
$con=new mysqli($host,$user,$pass,$db);
if($con->connect_error){
    die("connection failed:".$con->connect_error);
}
?>