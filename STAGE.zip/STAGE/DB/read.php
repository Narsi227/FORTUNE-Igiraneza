<?php
$host='localhost';//servername
$user='root';
$pass="";
$db='db_management';
//database connections
$con=new mysqli($host,$user,$pass,$db);
if($con->connect_error){
    die("connection failed:".$con->connect_error);
}
$sql="SELECT*FROM user";
$result=$con->query($sql);
?>
<html>
    <head>
        <style>
            table{
                width: 60%;
                border-collapse: collapse;
            }
            th,td{
                border: 1px solid #d2dd;
                padding: 8px;
                text-align: left;
            }
            th{
                background-color: #f2f2f2f3
            }
        </style>
    </head>
    <body>
        <h1>List of User Registered!</h1>
        <table>
            <tr>
                <th  style="background-color: yellow">ID</th>
                <th  style="background-color: green">Firstname</th>
                <th  style="background-color: brown">Lastname</th>
                <th  style="background-color: cyan">Email</th>
                <th style="background-color: blue">Action</th>
            </tr>
            <?php while($user=$result->fetch_assoc()):
            ?>
            <tr>
                <td><?php echo $user['id'] ?></td>
                <td><?php echo$user['fname'] ?></td>
                <td><?php echo$user['lname'] ?></td>
                <td><?php echo$user['email'] ?></td>
                <td>
                    <a href="update.php?id=<?php echo $user['id'] ?>">Update</a>&nbsp;|&nbsp;
                    <a href="delete.php?id=<?php echo $user['id'] ?>">Delete</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
        <a href="insert.php">Add New User</a>
        <a href="logout.php"><button>log out</button></a>
    </body>
</html>
<?php
$con->close();
?>