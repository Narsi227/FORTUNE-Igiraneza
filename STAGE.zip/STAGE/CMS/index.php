<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <nav style="text-align:center;">
        <a href="index.php">Home</a>&nbsp;&nbsp;&nbsp;
        <a href="register.php">Student Registration</a>&nbsp;&nbsp;&nbsp;
        <a href="admin/login.php">Admin Login</a>&nbsp;&nbsp;&nbsp;
    </nav>
    <div style="color: blue; text-align:center;background:yellow">
    <h1>Welcome to School CMS Page!</h1>
    <h2>Manage students easily</h2>
    </div>
</body>
</html>