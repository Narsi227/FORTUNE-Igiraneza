<?php
include 'config.php';
if(isset($_POST['save'])){
    $fullname=$_POST['fullname'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $gender=$_POST['gender'];
    mysqli_query($con,"INSERT INTO students(fullname,email,phone,gender) VALUE('$fullname','$email','$phone','$gender')");
}
?>
<head>
    <style>
        h1{
            text-decoration:underline;
            text-align:center;
            font-size:50px;
        }
        form{
            background-color:gold;
        }
        input{
            background-color:lime;
            color:blue;
        }
        option{
            background:pink;
        }
    </style>
</head>
<body>
    <h1 style="color:red">Register</h1>
    <form method="POST" style="text-align:center">
    FULLNAME:<input type="text" name="fullname" require><br>
    EMAIL:<input type="text" name="email" require><br>
    PHONE:<input type="text" name="phone" require><br>
    GENDER:<select name="gender" require >
        <option >Male</option>
        <option >Female</option><br>
    </select><br>
    <input type="submit" name="save" value="save">
</form>
</body>