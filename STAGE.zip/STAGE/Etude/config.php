<?php
$con=mysqli_connect("localhost","root","","project");
if(!$con){
    die("Database failed!");
}
?>