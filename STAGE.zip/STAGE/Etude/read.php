<?php
include "config.php";
if(isset($_POST['save'])){
    $name=$_POST['name'];
    $gender=$_POST['gender'];
     mysqli_query($con,"INSERT INTO etuid(name,gender) VALUE('$name','$gender')");
}
?>
<form method="POST" action="read.php">
    NAME:<input type="text" name="name" require>
    GENDER:<select name="gender" require>
        <option>Female</option>
        <option>Male</option>
    </select>
    <input type="submit" name="save" value="save">
</form>